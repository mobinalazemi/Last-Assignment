import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ListShuffler {

    public static void main(String[] args) {

        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);
        linkedList.add(5);

        System.out.println("Original List: " + linkedList);

        shuffleLinkedList(linkedList);

        System.out.println("Shuffled List: " + linkedList);
    }

    public static <T> void shuffleLinkedList(LinkedList<T> list) {

        List<T> t = new ArrayList<>(list);


        Collections.shuffle(t);


        list.clear();


        list.addAll(t);
    }
}