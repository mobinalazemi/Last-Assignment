import java.util.ArrayList;
 class ToDos {
    public static void main(String[] args) {

        ArrayList<String> poirotsToDos = new ArrayList<String>();
        poirotsToDos.add("interview suspects");
        poirotsToDos.add("visit the crime scene");
        poirotsToDos.add("let the little grey cells do their work");
        ArrayList<String>
                sherlocksToDos = new ArrayList<String>();
        sherlocksToDos.add("visit the crime scene");
        sherlocksToDos.add("solve the case");
        sherlocksToDos.add("interview suspects");
        sherlocksToDos.add("play violin");
        sherlocksToDos.add("apprehend the criminal");

        public static void main(String[] args) {
            poirotsToDos.add("reveal the truth of the crime");

            System.out.println("sherlocksToDo's size: "+ sherlocksToDos.size());
            System.out.println("poirotsToDo's size: "+ poirotsToDos.size());

            if(poirotsToDos.size()<sherlocksToDos.size()){
                System.out.println("Sherlock has more things to do");
            }
            else if(poirotsToDos.size()>sherlocksToDos.size()){
                System.out.println("Poirot has more things to do");
            } else if(poirotsToDos.size()==sherlocksToDos.size())
            { System.out.println("both detectives have same amount of things to do"); }
        }
    }
}

